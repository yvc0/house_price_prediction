# House-Price-Prediction--Django
To predict the price of house in Bangalore. Linear regression is used to predict the price of the house and Django acts a front end website. Python language is used.
